const express = require("express");
const app = express();

// Root route
app.get("/", (req, res) => {
  res.send("Hello from Azure Web App!");
});

// Use the port provided by Azure or default to 3000 locally
const PORT = process.env.PORT || 3000;

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
